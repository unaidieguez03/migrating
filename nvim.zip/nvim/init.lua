require("unai_conf")

vim.wo.number = true 
vim.wo.relativenumber = true
















