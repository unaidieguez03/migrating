local builtin = require('telescope.builtin')
local telescope = require('telescope')

vim.keymap.set('n', '<leader>ff', builtin.find_files, {})
vim.keymap.set('n', '<leader>fd', "<cmd>lua require'telescope.builtin'.find_files({hidden=true})<cr>", {})

vim.keymap.set('n', '<leader>fg', "<cmd>lua require'telescope.builtin'.live_grep({})<cr>", {})
vim.keymap.set('n', '<leader>fh', builtin.help_tags, {})
--telescope.setup {}
