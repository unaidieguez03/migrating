require("gruvbox").setup({
    palette_overrides = {
      bright_aqua = "#b36b2a",
      }
})
vim.cmd("colorscheme gruvbox")
